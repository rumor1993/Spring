package com.naver.myhome1.sample1;

public class MessageBeanEn {
	public void say(String name) {
		System.out.println("Hello!" + name );
	}
}
