package com.naver.myhome1.sample1;

public class MessageBeanKo {
	public void sayHello(String name) {
		System.out.println("�Ʒ��ϼ���!" + name );
	}
}
